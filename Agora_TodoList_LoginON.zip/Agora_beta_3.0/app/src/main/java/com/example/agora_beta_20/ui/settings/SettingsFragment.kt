package com.example.agora_beta_20.ui.settings

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.example.agora_beta_20.R
import com.example.agora_beta_20.databinding.FragmentSettingsBinding
import com.example.agora_beta_20.ui.login.LoginActivity

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Account Setting 버튼 클릭 리스너 설정
        binding.cardAccountSetting.setOnClickListener {
            showLogoutConfirmationDialog()
        }

        return root
    }

    private fun showLogoutConfirmationDialog() {
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("로그아웃")
        builder.setMessage("정말 로그아웃하시겠습니까?")
        builder.setPositiveButton("확인") { _, _ ->
            performLogout()
        }
        builder.setNegativeButton("취소") { dialog, _ ->
            dialog.dismiss()
        }
        builder.show()
    }

    private fun performLogout() {
        // SharedPreferences에서 인증 정보 삭제
        val sharedPreferences = requireContext().getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
        sharedPreferences.edit().clear().apply()

        // 사용자에게 로그아웃 완료 메시지 표시
        Toast.makeText(requireContext(), "로그아웃 되었습니다.", Toast.LENGTH_SHORT).show()

        // 로그인 화면으로 이동
        val intent = Intent(requireContext(), LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK // 기존 스택 제거
        startActivity(intent)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

//class SettingsFragment : Fragment() {
//
//    private var _binding: FragmentSettingsBinding? = null
//    private val binding get() = _binding!!
//
//    override fun onCreateView(
//        inflater: LayoutInflater,
//        container: ViewGroup?,
//        savedInstanceState: Bundle?
//    ): View? {
//        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
//        val root: View = binding.root
//
//
//        // !! 설정은 다시 하기 !!
//
//
//        // Account Setting 버튼 클릭 리스너 설정
//        binding.cardAccountSetting.setOnClickListener {
//            // Account Setting 페이지로 이동하는 로직을 추가
//            Toast.makeText(requireContext(), "Account Setting Clicked", Toast.LENGTH_SHORT).show()
//
//            // 실제로는 AccountSettingsActivity로 이동하거나, 다른 프래그먼트로 네비게이션
//        }
//
////        // Light/Dark Mode 스위치 초기 상태 설정
////        val currentNightMode = AppCompatDelegate.getDefaultNightMode()
////        binding.switchTheme.isChecked = currentNightMode == AppCompatDelegate.MODE_NIGHT_YES
////
////        // Light/Dark Mode 스위치 리스너 설정
////        binding.switchTheme.setOnCheckedChangeListener { _, isChecked ->
////            if (isChecked) {
////                // 다크 모드로 전환
////                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
////                Toast.makeText(requireContext(), "Dark Mode Enabled", Toast.LENGTH_SHORT).show()
////            } else {
////                // 라이트 모드로 전환
////                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
////                Toast.makeText(requireContext(), "Light Mode Enabled", Toast.LENGTH_SHORT).show()
////            }
////            // 액티비티 재시작하여 테마 적용
////            activity?.recreate()
////        }
//
//        return root
//    }
//
//    override fun onDestroyView() {
//        super.onDestroyView()
//        _binding = null
//    }
//}